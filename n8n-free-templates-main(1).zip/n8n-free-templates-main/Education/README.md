# Education Templates

- **quiz_auto_grader.json** – Uses Cohere Embeddings, OpenAI Chat, Pinecone
- **daily_student_motivation.json** – Uses OpenAI Chat, OpenAI Embeddings