# HR Templates

- **new_job_application_parser.json** – Uses OpenAI Chat, OpenAI Embeddings, Pinecone
- **notion_job_board_poster.json** – Uses OpenAI Chat, OpenAI Embeddings, Supabase Vector