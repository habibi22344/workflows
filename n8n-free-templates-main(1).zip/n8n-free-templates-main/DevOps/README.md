# DevOps Templates

- **github_commit_jenkins.json** – Uses OpenAI Chat, OpenAI Embeddings, Supabase Vector