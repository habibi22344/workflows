# Healthcare Templates

- **appointment_whatsapp_notify.json** – Uses OpenAI Chat, OpenAI Embeddings, Supabase Vector